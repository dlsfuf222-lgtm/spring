package com.intheeast.ioc.javabasedcontainerconfiguration.usingtheconfigurationannotation.furtherinformation.client;

public interface ClientService {
	void process();
}