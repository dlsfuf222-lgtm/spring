package com.intheeast.ioc.javabasedcontainerconfiguration.instantiatingthespringcontainer.buildingthecontainerprogrammatically.dependency;

public class Dependency2 {
	public String getInfo() {
		return "Info from Dependency2";
	}
}