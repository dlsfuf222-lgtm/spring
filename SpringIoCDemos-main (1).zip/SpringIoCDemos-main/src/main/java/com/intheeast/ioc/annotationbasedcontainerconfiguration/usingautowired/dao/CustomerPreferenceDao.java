package com.intheeast.ioc.annotationbasedcontainerconfiguration.usingautowired.dao;

public interface CustomerPreferenceDao {
    String getCustomerPreference();
}
