package com.intheeast.ioc.beandefinitioninheritance.repository;

public class YourRepository {

}
