package com.intheeast.ioc.annotationbasedcontainerconfiguration.usingcustomautowire.service;


public interface MyService {
    void doSomething();
}
