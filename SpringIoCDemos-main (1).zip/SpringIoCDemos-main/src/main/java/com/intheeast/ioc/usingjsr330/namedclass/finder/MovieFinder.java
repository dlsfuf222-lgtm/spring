package com.intheeast.ioc.usingjsr330.namedclass.finder;

public interface MovieFinder {
    String findAll();
}
