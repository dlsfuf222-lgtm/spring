package com.intheeast.ioc.javabasedcontainerconfiguration.usingtheconfigurationannotation.furtherinformation.client;

public interface ClientDao {
	void save();
}
