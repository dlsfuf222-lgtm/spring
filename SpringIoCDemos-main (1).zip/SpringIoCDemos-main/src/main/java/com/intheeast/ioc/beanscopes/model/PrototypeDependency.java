package com.intheeast.ioc.beanscopes.model;

public class PrototypeDependency {
    public PrototypeDependency() {
        System.out.println("PrototypeDependency instance created");
    }
}