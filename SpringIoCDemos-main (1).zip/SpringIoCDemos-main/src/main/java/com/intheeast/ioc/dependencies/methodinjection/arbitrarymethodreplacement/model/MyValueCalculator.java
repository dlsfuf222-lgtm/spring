package com.intheeast.ioc.dependencies.methodinjection.arbitrarymethodreplacement.model;

public class MyValueCalculator {

    public String computeValue(String input) throws Throwable {
        // Original implementation
        return "Original Value: " + input;
    }
}