package com.intheeast.ioc.beanoverview.service;

public class SingleTonType {

}
