package com.intheeast.ioc.beanfactoryapi.defaultbeanfactory;

public class Printer {
	
	public void print(String message) {
		System.out.println("printer:" + message);
	}

}
