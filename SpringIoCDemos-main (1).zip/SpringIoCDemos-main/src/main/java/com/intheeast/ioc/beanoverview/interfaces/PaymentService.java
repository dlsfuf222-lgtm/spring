package com.intheeast.ioc.beanoverview.interfaces;

public interface PaymentService {
    void pay(double amount);
}