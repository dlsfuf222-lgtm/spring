package com.intheeast.ioc.environmentabstraction.beandefinitionprofiles.service;

public interface NotificationService {
    void send(String message);
}