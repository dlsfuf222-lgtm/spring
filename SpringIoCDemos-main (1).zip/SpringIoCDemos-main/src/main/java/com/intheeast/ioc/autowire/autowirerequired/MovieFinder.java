package com.intheeast.ioc.autowire.autowirerequired;

public interface MovieFinder {
	void findMovies();
}
