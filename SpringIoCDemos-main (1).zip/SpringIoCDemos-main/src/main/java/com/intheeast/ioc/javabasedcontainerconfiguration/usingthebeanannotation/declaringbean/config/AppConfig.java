package com.intheeast.ioc.javabasedcontainerconfiguration.usingthebeanannotation.declaringbean.config;

import org.springframework.context.annotation.Configuration;

@Configuration
public class AppConfig implements BaseConfig {

}