package com.intheeast.ioc.javabasedcontainerconfiguration.instantiatingthespringcontainer.buildingthecontainerprogrammatically.dependency;

public class Dependency1 {
	public String getMessage() {
		return "Message from Dependency1";
	}
}