package com.intheeast.ioc.annotationbasedcontainerconfiguration.finetuningannotationbasedautowiringwithqualifiers.domain;

public enum Format {
    VHS, DVD, BLURAY
}
