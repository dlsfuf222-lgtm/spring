package com.intheeast.ioc.annotationbasedcontainerconfiguration.usingautowired.util;

public interface MovieCatalog {
    String getCatalogName();
}
