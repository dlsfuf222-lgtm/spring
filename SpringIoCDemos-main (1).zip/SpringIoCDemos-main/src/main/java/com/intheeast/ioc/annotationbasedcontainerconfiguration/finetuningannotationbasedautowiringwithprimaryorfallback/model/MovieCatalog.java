package com.intheeast.ioc.annotationbasedcontainerconfiguration.finetuningannotationbasedautowiringwithprimaryorfallback.model;


public interface MovieCatalog {
    String getCatalogName();
}
