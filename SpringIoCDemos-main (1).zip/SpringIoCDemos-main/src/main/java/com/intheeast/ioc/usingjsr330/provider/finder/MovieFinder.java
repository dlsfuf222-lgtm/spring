package com.intheeast.ioc.usingjsr330.provider.finder;

public interface MovieFinder {
    String findAll();
}
