package com.intheeast.ioc.dependencies.dependson.model;

public class ManagerBean {
    public ManagerBean() {
        System.out.println("ManagerBean initialized");
    }
}