package com.intheeast.ioc.dependencies.dependencyinjection.service;

public interface MovieFinder {
	String findMovies();
}
