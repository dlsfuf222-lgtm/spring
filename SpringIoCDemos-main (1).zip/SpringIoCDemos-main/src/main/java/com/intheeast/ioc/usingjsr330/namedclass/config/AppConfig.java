package com.intheeast.ioc.usingjsr330.namedclass.config;

import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;

@Configuration
@ComponentScan({"com.intheeast.ioc.usingjsr330.namedclass"})
public class AppConfig {

	
}
