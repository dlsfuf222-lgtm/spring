package com.intheeast.ioc.annotationbasedcontainerconfiguration.finetuningannotationbasedautowiringwithprimaryorfallback.qualifiers;

public enum Format {
    VHS, DVD, BLURAY
}
