package com.intheeast.ioc.usingjsr330.inject.finder;

public interface MovieFinder {
    String findAll();
}
