package com.intheeast.ioc.beanscopes.model;

public class DefaultAccountService {
    public DefaultAccountService() {
        System.out.println("DefaultAccountService instance created");
    }
}