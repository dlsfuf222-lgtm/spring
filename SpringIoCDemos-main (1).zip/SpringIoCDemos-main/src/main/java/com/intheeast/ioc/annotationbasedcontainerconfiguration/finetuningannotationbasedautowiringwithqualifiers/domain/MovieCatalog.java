package com.intheeast.ioc.annotationbasedcontainerconfiguration.finetuningannotationbasedautowiringwithqualifiers.domain;

public interface MovieCatalog {
    String getCatalogName();
}
