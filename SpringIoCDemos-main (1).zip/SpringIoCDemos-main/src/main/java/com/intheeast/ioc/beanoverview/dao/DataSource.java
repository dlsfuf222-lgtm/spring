package com.intheeast.ioc.beanoverview.dao;

public class DataSource {
    public DataSource() {
        System.out.println("DataSource created.");
    }
}