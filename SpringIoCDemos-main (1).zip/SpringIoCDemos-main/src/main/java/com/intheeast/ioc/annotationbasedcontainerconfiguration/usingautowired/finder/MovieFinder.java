package com.intheeast.ioc.annotationbasedcontainerconfiguration.usingautowired.finder;

public interface MovieFinder {
    String findAll();
}
