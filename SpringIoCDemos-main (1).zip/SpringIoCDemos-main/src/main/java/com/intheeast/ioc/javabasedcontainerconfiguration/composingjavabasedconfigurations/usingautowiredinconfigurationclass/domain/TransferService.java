package com.intheeast.ioc.javabasedcontainerconfiguration.composingjavabasedconfigurations.usingautowiredinconfigurationclass.domain;

public interface TransferService {
	void transfer(double amount, String fromAccount, String toAccount);
}
