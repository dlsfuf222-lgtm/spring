package com.intheeast.ioc.containerextensionpoints.beanfactorypostprocessor.example2.model;

public class ServiceStrategy {

    public void execute() {
        System.out.println("Executing default ServiceStrategy.");
    }
}
