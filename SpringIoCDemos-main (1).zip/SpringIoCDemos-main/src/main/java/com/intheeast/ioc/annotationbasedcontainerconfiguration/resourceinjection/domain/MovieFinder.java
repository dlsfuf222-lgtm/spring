package com.intheeast.ioc.annotationbasedcontainerconfiguration.resourceinjection.domain;


public interface MovieFinder {
    String findMovieByTitle(String title);
}
