package com.intheeast.ioc.dependencies.dependson.model;

public class JdbcAccountDao {
    public JdbcAccountDao() {
        System.out.println("JdbcAccountDao initialized");
    }
}