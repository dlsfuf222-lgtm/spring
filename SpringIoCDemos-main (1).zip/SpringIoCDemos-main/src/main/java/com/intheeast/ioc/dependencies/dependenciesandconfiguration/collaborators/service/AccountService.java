package com.intheeast.ioc.dependencies.dependenciesandconfiguration.collaborators.service;

public class AccountService {
    public void performOperation() {
        System.out.println("Performing account operation...");
    }
}