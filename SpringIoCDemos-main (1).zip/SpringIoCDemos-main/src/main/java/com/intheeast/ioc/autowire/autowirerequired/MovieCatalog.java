package com.intheeast.ioc.autowire.autowirerequired;

public interface MovieCatalog {
    String getCatalogName();
    void displayMovies();
}
