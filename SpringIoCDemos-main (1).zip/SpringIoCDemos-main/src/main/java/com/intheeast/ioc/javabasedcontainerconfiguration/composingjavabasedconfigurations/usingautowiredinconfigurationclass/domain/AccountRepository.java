package com.intheeast.ioc.javabasedcontainerconfiguration.composingjavabasedconfigurations.usingautowiredinconfigurationclass.domain;

public interface AccountRepository {
	void updateAccount(String accountNumber, double amount);
}
