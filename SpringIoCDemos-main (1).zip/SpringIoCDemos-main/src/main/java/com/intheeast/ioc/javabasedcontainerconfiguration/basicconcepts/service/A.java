package com.intheeast.ioc.javabasedcontainerconfiguration.basicconcepts.service;

public class A {
	
	public A() {
		System.out.println("A 인스턴스 생성됨:" + this);
	}

}
