package com.intheeast.ioc.beanoverview.dao;

public interface AccountDao {
	void saveAccount(String account);
}

