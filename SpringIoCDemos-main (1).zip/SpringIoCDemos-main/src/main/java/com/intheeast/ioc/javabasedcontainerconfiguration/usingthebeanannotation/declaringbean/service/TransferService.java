package com.intheeast.ioc.javabasedcontainerconfiguration.usingthebeanannotation.declaringbean.service;

public interface TransferService {
	
	public void transfer();

}
