package com.intheeast.ioc.javabasedcontainerconfiguration.composingjavabasedconfigurations.usingImportannotation.beans;

public class BeanB {

}
