package com.intheeast.ioc.javabasedcontainerconfiguration.enablingcomponentscanning.service;

public interface MyService {
	void doStuff();
}