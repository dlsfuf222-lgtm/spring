package com.intheeast.ioc.javabasedcontainerconfiguration.usingtheconfigurationannotation.injectinginterbeandependencies.model;

public class BeanTwo {

}
