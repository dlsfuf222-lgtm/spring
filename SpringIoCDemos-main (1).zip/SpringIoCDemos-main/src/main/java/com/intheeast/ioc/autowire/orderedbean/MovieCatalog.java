package com.intheeast.ioc.autowire.orderedbean;

public interface MovieCatalog {
    String getCatalogName();
    void displayMovies();
}
