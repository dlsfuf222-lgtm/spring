package com.intheeast.ioc.usingjsr330.named.finder;

public interface MovieFinder {
    String findAll();
}
