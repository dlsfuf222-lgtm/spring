package com.intheeast.ioc.dependencies.dependenciesandconfiguration.idref.service;

public class TargetBean {

}
