package com.intheeast.ioc.dependencies.lazy.model;

public class AnotherBean {
    public AnotherBean() {
        System.out.println("AnotherBean initialized");
    }
}