package com.intheeast.ioc.annotationbasedcontainerconfiguration.resourceinjection.domain;


public class CustomerPreferenceDao {
    public String getPreferences() {
        return "User preferences from DAO";
    }
}
