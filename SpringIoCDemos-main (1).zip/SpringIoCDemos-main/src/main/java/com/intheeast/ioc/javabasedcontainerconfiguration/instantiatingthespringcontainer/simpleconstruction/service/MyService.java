package com.intheeast.ioc.javabasedcontainerconfiguration.instantiatingthespringcontainer.simpleconstruction.service;

public interface MyService {
    void doStuff();
}