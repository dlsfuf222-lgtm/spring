package com.intheeast.ioc.beanfactoryapi;

public class MessageService {
    public String getMessage() {
        return "📨 메시지 전송 완료!";
    }
}
