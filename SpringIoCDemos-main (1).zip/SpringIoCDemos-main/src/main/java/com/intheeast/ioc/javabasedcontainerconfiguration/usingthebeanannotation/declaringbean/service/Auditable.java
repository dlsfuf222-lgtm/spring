package com.intheeast.ioc.javabasedcontainerconfiguration.usingthebeanannotation.declaringbean.service;

public interface Auditable {
	void audit();
}