package com.intheeast.ioc.dependencies.autowiring;

public interface PaymentService {
    void pay(int amount);
}
