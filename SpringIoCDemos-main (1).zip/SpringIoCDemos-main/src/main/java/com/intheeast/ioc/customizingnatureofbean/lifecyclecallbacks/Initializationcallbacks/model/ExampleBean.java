package com.intheeast.ioc.customizingnatureofbean.lifecyclecallbacks.Initializationcallbacks.model;

public class ExampleBean {

    public void init() {
        System.out.println("ExampleBean: Initialization logic executed.");
    }
}