package com.intheeast.ioc.usingjsr330.optional.finder;

public interface MovieFinder {
    String findAll();
}
