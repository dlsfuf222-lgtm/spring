package com.intheeast.ioc.beandefinitioninheritance.service;

public class MyService {

}
