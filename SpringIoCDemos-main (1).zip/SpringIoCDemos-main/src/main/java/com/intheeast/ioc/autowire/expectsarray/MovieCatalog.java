package com.intheeast.ioc.autowire.expectsarray;

public interface MovieCatalog {
    String getCatalogName();
    void displayMovies();
}