package com.intheeast.ioc.dependencies.lazy.lazyconfiguration.service;

public class AnotherBean {
	
	public AnotherBean() {
		System.out.println("+AnotherBean");
	}

}
