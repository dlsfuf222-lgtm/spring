package com.intheeast.ioc.componentconfig.beans;

public class TestBeanA {
	
	

}
